import { describe, expect, it } from 'vitest';
import { getMonthGrid, getWeekDays, startOfWeek, toDateKey } from './date';

describe('date helpers', () => {
  it('starts week on Monday when date is Sunday', () => {
    expect(toDateKey(startOfWeek(new Date(2026, 7, 23)))).toBe('2026-08-17');
  });

  it('crosses month boundary correctly inside a week', () => {
    const days = getWeekDays(new Date(2026, 7, 31));
    expect(days.map(toDateKey)).toEqual([
      '2026-08-31',
      '2026-09-01',
      '2026-09-02',
      '2026-09-03',
      '2026-09-04',
      '2026-09-05',
      '2026-09-06',
    ]);
  });

  it('crosses year boundary correctly', () => {
    const days = getWeekDays(new Date(2026, 11, 31));
    expect(days.map(toDateKey)).toEqual([
      '2026-12-28',
      '2026-12-29',
      '2026-12-30',
      '2026-12-31',
      '2027-01-01',
      '2027-01-02',
      '2027-01-03',
    ]);
  });

  it('builds a stable 42-cell month grid starting on Monday', () => {
    const grid = getMonthGrid(new Date(2026, 7, 21));
    expect(grid).toHaveLength(42);
    expect(toDateKey(grid[0])).toBe('2026-07-27');
    expect(toDateKey(grid[41])).toBe('2026-09-06');
  });
});
