export type TaskPriority = 'low' | 'medium' | 'high';

export interface Task {
  id: number;
  title: string;
  date: string;
  priority: TaskPriority;
  completed?: boolean;
}
