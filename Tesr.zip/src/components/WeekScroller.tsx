import { useEffect, useRef } from 'react';
import { toDateKey } from '../lib/date';
import { DayButton } from './DayButton';

interface WeekScrollerProps {
  days: Date[];
  selectedDate: Date;
  today: Date;
  onSelect: (day: Date) => void;
}

export function WeekScroller({ days, selectedDate, today, onSelect }: WeekScrollerProps) {
  const scrollerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const selectedElement = scrollerRef.current?.querySelector<HTMLElement>(
      `[data-date="${toDateKey(selectedDate)}"]`,
    );

    selectedElement?.scrollIntoView({
      behavior: 'smooth',
      inline: 'center',
      block: 'nearest',
    });
  }, [selectedDate]);

  return (
    <div className="week-scroller" ref={scrollerRef} aria-label="Дни недели">
      {days.map((day) => (
        <DayButton
          key={toDateKey(day)}
          day={day}
          selectedDate={selectedDate}
          today={today}
          onSelect={onSelect}
        />
      ))}
    </div>
  );
}
