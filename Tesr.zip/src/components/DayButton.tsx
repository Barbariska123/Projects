import { memo } from 'react';
import { isSameDay, shortWeekday, toDateKey } from '../lib/date';

interface DayButtonProps {
  day: Date;
  selectedDate: Date;
  today: Date;
  onSelect: (day: Date) => void;
}

export const DayButton = memo(function DayButton({
  day,
  selectedDate,
  today,
  onSelect,
}: DayButtonProps) {
  const isSelected = isSameDay(day, selectedDate);
  const isToday = isSameDay(day, today);

  return (
    <button
      className={`day-card ${isSelected ? 'day-card--selected' : ''}`}
      type="button"
      aria-pressed={isSelected}
      aria-label={day.toLocaleDateString('ru-RU', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
      })}
      data-date={toDateKey(day)}
      onClick={() => onSelect(day)}
    >
      <span className="day-card__weekday">{shortWeekday(day)}</span>
      <span className="day-card__number">{day.getDate()}</span>
      {isToday && <span className="day-card__today">сегодня</span>}
    </button>
  );
});
