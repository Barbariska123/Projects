import { isSameDay, isSameMonth, shortWeekday, toDateKey } from '../lib/date';

interface MonthGridProps {
  days: Date[];
  visibleMonth: Date;
  selectedDate: Date;
  today: Date;
  onSelect: (day: Date) => void;
}

const weekdayHeaders = Array.from({ length: 7 }, (_, index) => {
  const monday = new Date(2024, 0, 1, 12);
  monday.setDate(monday.getDate() + index);
  return shortWeekday(monday);
});

export function MonthGrid({
  days,
  visibleMonth,
  selectedDate,
  today,
  onSelect,
}: MonthGridProps) {
  return (
    <div className="month-wrap">
      <div className="month-weekdays" aria-hidden="true">
        {weekdayHeaders.map((weekday) => (
          <span key={weekday}>{weekday}</span>
        ))}
      </div>

      <div className="month-grid" role="grid" aria-label="Календарь месяца">
        {days.map((day) => {
          const selected = isSameDay(day, selectedDate);
          const outside = !isSameMonth(day, visibleMonth);
          const isToday = isSameDay(day, today);

          return (
            <button
              key={toDateKey(day)}
              className={[
                'month-day',
                selected ? 'month-day--selected' : '',
                outside ? 'month-day--outside' : '',
                isToday ? 'month-day--today' : '',
              ]
                .filter(Boolean)
                .join(' ')}
              type="button"
              aria-pressed={selected}
              onClick={() => onSelect(day)}
            >
              {day.getDate()}
            </button>
          );
        })}
      </div>
    </div>
  );
}
