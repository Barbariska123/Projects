import type { Task } from '../types';

interface TaskListProps {
  tasks: Task[];
}

const priorityText = {
  low: 'Низкий',
  medium: 'Средний',
  high: 'Высокий',
} as const;

export function TaskList({ tasks }: TaskListProps) {
  if (tasks.length === 0) {
    return (
      <div className="empty-state">
        <span className="empty-state__icon">✓</span>
        <strong>На этот день задач нет</strong>
        <span>Можно немного выдохнуть.</span>
      </div>
    );
  }

  return (
    <div className="task-list">
      {tasks.map((task) => (
        <article className="task-item" key={task.id}>
          <span className={`task-item__dot task-item__dot--${task.priority}`} />
          <div className="task-item__content">
            <strong>{task.title}</strong>
            <span>{priorityText[task.priority]} приоритет</span>
          </div>
        </article>
      ))}
    </div>
  );
}
