import type { Task } from './types';

export const tasks: Task[] = [
  { id: 1, title: 'Проверить авторизацию', date: '2026-08-21', priority: 'high' },
  { id: 2, title: 'Доделать календарь', date: '2026-08-21', priority: 'medium' },
  { id: 3, title: 'Исправить адаптив', date: '2026-08-22', priority: 'low' },
  { id: 4, title: 'Подключить API задач', date: '2026-08-24', priority: 'high' },
  { id: 5, title: 'Проверить пустые состояния', date: '2026-08-31', priority: 'medium' },
  { id: 6, title: 'Подготовить README', date: '2026-09-01', priority: 'low' },
];
