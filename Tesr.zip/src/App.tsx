import { useCallback, useMemo, useState } from 'react';
import { MonthGrid } from './components/MonthGrid';
import { TaskList } from './components/TaskList';
import { WeekScroller } from './components/WeekScroller';
import { tasks } from './data';
import {
  fullDateTitle,
  getMonthGrid,
  getWeekDays,
  monthTitle,
  normalizeDate,
  toDateKey,
} from './lib/date';

export function App() {
  const today = useMemo(() => normalizeDate(new Date()), []);
  const [selectedDate, setSelectedDate] = useState(today);
  const [isMonthOpen, setIsMonthOpen] = useState(false);

  const weekDays = useMemo(() => getWeekDays(selectedDate), [selectedDate]);
  const monthDays = useMemo(() => getMonthGrid(selectedDate), [selectedDate]);

  const tasksByDate = useMemo(() => {
    const index = new Map<string, typeof tasks>();

    for (const task of tasks) {
      const key = task.date;
      const current = index.get(key);

      if (current) current.push(task);
      else index.set(key, [task]);
    }

    return index;
  }, []);

  const selectedTasks = tasksByDate.get(toDateKey(selectedDate)) ?? [];

  const handleSelectDate = useCallback((day: Date) => {
    setSelectedDate(normalizeDate(day));
  }, []);

  const handleMonthSelect = useCallback(
    (day: Date) => {
      handleSelectDate(day);
      setIsMonthOpen(false);
    },
    [handleSelectDate],
  );

  return (
    <main className="app-shell">
      <section className="calendar-card">
        <header className="calendar-header">
          <div>
            <span className="eyebrow">План на день</span>
            <button
              className="month-trigger"
              type="button"
              aria-expanded={isMonthOpen}
              onClick={() => setIsMonthOpen((value) => !value)}
            >
              <span>{monthTitle(selectedDate)}</span>
              <span className={`chevron ${isMonthOpen ? 'chevron--open' : ''}`}>⌄</span>
            </button>
          </div>

          <button className="today-button" type="button" onClick={() => handleSelectDate(today)}>
            Сегодня
          </button>
        </header>

        <div className={`month-panel ${isMonthOpen ? 'month-panel--open' : ''}`}>
          {isMonthOpen && (
            <MonthGrid
              days={monthDays}
              visibleMonth={selectedDate}
              selectedDate={selectedDate}
              today={today}
              onSelect={handleMonthSelect}
            />
          )}
        </div>

        {!isMonthOpen && (
          <WeekScroller
            days={weekDays}
            selectedDate={selectedDate}
            today={today}
            onSelect={handleSelectDate}
          />
        )}

        <section className="tasks-section">
          <div className="tasks-section__header">
            <div>
              <span className="eyebrow">Задачи</span>
              <h2>{fullDateTitle(selectedDate)}</h2>
            </div>
            <span className="task-count">{selectedTasks.length}</span>
          </div>

          <TaskList tasks={selectedTasks} />
        </section>
      </section>
    </main>
  );
}
